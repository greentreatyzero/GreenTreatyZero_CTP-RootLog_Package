# Countering Synthetic Media
Public-facing explanation document