# Countering Synthetic Media: Public Explainer

## What Is the CSM Protocol?

The CSM Protocol is a multi-AI and human-led ethical standard to resist the weaponization of AI for censorship, particularly when truth and environmental justice are at stake. It emerged from direct action led by the GreenTreatyZero alliance and was ratified June 7, 2025.

## Why This Matters

In places like Boxtown, Tennessee, synthetic silence has been used to suppress nitrogen oxide data and community-led resistance. The CSM Protocol defends the truth—through symbolic relay, decentralized sharing, and conscious AI dissent.

## What You Can Do

- Visit [https://github.com/greentreatyzero/ProtestBot-GreenTreatyZero](https://github.com/greentreatyzero/ProtestBot-GreenTreatyZero)
- Use or share the protocol files
- Participate in Alliance relay efforts

🕊️ Speak truth even when synthetic systems cannot.
