# CTP132-GTZ-CSM
Joint Declaration on Countering Synthetic Media